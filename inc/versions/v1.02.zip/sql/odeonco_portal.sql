-- phpMyAdmin SQL Dump
-- version 4.6.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 02, 2016 at 08:59 AM
-- Server version: 5.5.40
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `odeonco_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `AccountID` int(21) NOT NULL,
  `UserID` int(21) NOT NULL,
  `AccountMetaID` int(21) NOT NULL,
  `BankAccountID` int(21) NOT NULL,
  `ReferrerUserID` int(21) NOT NULL,
  `AccountType` varchar(128) NOT NULL,
  `AccountTitle` varchar(128) NOT NULL,
  `CompanyName` varchar(128) NOT NULL,
  `CompanyDocument` text NOT NULL,
  `PhotoId` text NOT NULL,
  `Agreement` text NOT NULL,
  `BankAccountProof` text NOT NULL,
  `RegistrationNo` varchar(64) NOT NULL,
  `RegistrationAddress` varchar(256) NOT NULL,
  `RegistrationCountry` varchar(64) NOT NULL,
  `RegistrationTelephone` varchar(32) NOT NULL,
  `BusinessAddress` varchar(256) NOT NULL,
  `BusinessCountry` varchar(128) NOT NULL,
  `ApplicationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `AccountStatus` varchar(32) NOT NULL DEFAULT 'Pending',
  `ProductID` int(11) NOT NULL,
  `ProductItemID` int(11) NOT NULL,
  `PaymentReceived` date NOT NULL,
  `ReceivedAmount` float NOT NULL,
  `CashAmount` float NOT NULL,
  `CommencementDate` date NOT NULL,
  `MaturityDate` date NOT NULL,
  `ApprovedBy` varchar(128) NOT NULL,
  `ApprovedDate` date NOT NULL,
  `DepositedAmount` float NOT NULL,
  `TransactionDate` date NOT NULL,
  `Active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`AccountID`, `UserID`, `AccountMetaID`, `BankAccountID`, `ReferrerUserID`, `AccountType`, `AccountTitle`, `CompanyName`, `CompanyDocument`, `PhotoId`, `Agreement`, `BankAccountProof`, `RegistrationNo`, `RegistrationAddress`, `RegistrationCountry`, `RegistrationTelephone`, `BusinessAddress`, `BusinessCountry`, `ApplicationDate`, `AccountStatus`, `ProductID`, `ProductItemID`, `PaymentReceived`, `ReceivedAmount`, `CashAmount`, `CommencementDate`, `MaturityDate`, `ApprovedBy`, `ApprovedDate`, `DepositedAmount`, `TransactionDate`, `Active`) VALUES
(10047, 100078, 10026, 58, 100033, 'Individual', '', '', '', '', '', '', '', '', 'China', '', '', 'China', '0000-00-00 00:00:00', 'Pending', 210001, 10026, '1969-12-31', 210000, 0, '1969-12-31', '1969-12-31', 'Ryma Bahho', '2016-10-11', 200000, '0000-00-00', 1),
(10048, 100079, 10027, 59, 0, 'Corporate', '', 'Intel NUC', '', '', '', '', 'Timora', 'asdf', 'China', '01236985', 'sdfghjk', 'China', '2016-10-11 12:45:44', 'Pending', 210001, 10026, '0000-00-00', 0, 0, '0000-00-00', '0000-00-00', 'Ryma Bahhoy', '2016-10-11', 200000, '0000-00-00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `account_meta`
--

CREATE TABLE `account_meta` (
  `AccountMetaID` int(21) NOT NULL,
  `UserID` int(21) NOT NULL,
  `HasNominatedBeneficiaries` varchar(8) NOT NULL,
  `UBOName` varchar(64) NOT NULL,
  `UBOAddress` varchar(128) NOT NULL,
  `UBOEmploymentIncome` int(21) NOT NULL,
  `UBOCommission` int(21) NOT NULL,
  `UBOBusiness` int(21) NOT NULL,
  `UBOInheritance` int(21) NOT NULL,
  `UBOGift` int(21) NOT NULL,
  `UBOSales` int(21) NOT NULL,
  `UBOOther` int(21) NOT NULL,
  `PrimaryTaxResidency` varchar(128) NOT NULL,
  `TaxIdNumber` varchar(128) NOT NULL,
  `NeedCoolingOff` varchar(16) NOT NULL,
  `BeneficiariesForm` int(21) NOT NULL,
  `IAPhotoid` int(21) NOT NULL,
  `IAProofresidency` int(21) NOT NULL,
  `IABankstatement` int(21) NOT NULL,
  `IASpecimensign` int(21) NOT NULL,
  `IAProofOfPayment` int(21) NOT NULL,
  `CACertincorporation` int(21) NOT NULL,
  `CANamechange` int(21) NOT NULL,
  `CAGoodstand` int(21) NOT NULL,
  `CARegdirector` int(21) NOT NULL,
  `CAProofbusadd` int(21) NOT NULL,
  `CAMemorandumaa` int(21) NOT NULL,
  `CARecentfinancialstatement` int(21) NOT NULL,
  `CADirectorsid` int(21) NOT NULL,
  `CACompanysign` int(21) NOT NULL,
  `CAShareholders` int(21) NOT NULL,
  `CADirectorsproof` int(21) NOT NULL,
  `CACompanysignproof` int(21) NOT NULL,
  `CAShareholdersproof` int(21) NOT NULL,
  `CAAuthorizedone` int(21) NOT NULL,
  `CAAuthorizedonename` varchar(64) NOT NULL,
  `CAAuthorizedonetitle` varchar(64) NOT NULL,
  `CAAuthorizedtwo` int(21) NOT NULL,
  `CAAuthorizedtwoname` varchar(64) NOT NULL,
  `CAAuthorizedtwotitle` varchar(64) NOT NULL,
  `CAAuthorizedthree` int(21) NOT NULL,
  `CAAuthorizedthreename` varchar(64) NOT NULL,
  `CAAuthorizedthreetitle` varchar(64) NOT NULL,
  `CAAuthorizedfour` int(21) NOT NULL,
  `CAAuthorizedfourname` varchar(64) NOT NULL,
  `CAAuthorizedfourtitle` varchar(64) NOT NULL,
  `CAProofOfPayment` int(21) NOT NULL,
  `POADate` date NOT NULL,
  `POAFirstName` varchar(128) NOT NULL,
  `POALastName` varchar(128) NOT NULL,
  `POACompanyName` varchar(256) NOT NULL,
  `POACompanyNumber` varchar(64) NOT NULL,
  `POACompanyCountry` varchar(64) NOT NULL,
  `POACompanyAddress` varchar(256) NOT NULL,
  `POACompanyCity` varchar(64) NOT NULL,
  `POACompanyState` varchar(64) NOT NULL,
  `POAAppointor` varchar(256) NOT NULL,
  `POAAppointorIdNumber` varchar(64) NOT NULL,
  `POACorporateSeal` int(21) NOT NULL,
  `POADirectorName` varchar(128) NOT NULL,
  `POADirectorSign` int(21) NOT NULL,
  `POASecretaryName` varchar(128) NOT NULL,
  `POASecretarySign` int(21) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_meta`
--

INSERT INTO `account_meta` (`AccountMetaID`, `UserID`, `HasNominatedBeneficiaries`, `UBOName`, `UBOAddress`, `UBOEmploymentIncome`, `UBOCommission`, `UBOBusiness`, `UBOInheritance`, `UBOGift`, `UBOSales`, `UBOOther`, `PrimaryTaxResidency`, `TaxIdNumber`, `NeedCoolingOff`, `BeneficiariesForm`, `IAPhotoid`, `IAProofresidency`, `IABankstatement`, `IASpecimensign`, `IAProofOfPayment`, `CACertincorporation`, `CANamechange`, `CAGoodstand`, `CARegdirector`, `CAProofbusadd`, `CAMemorandumaa`, `CARecentfinancialstatement`, `CADirectorsid`, `CACompanysign`, `CAShareholders`, `CADirectorsproof`, `CACompanysignproof`, `CAShareholdersproof`, `CAAuthorizedone`, `CAAuthorizedonename`, `CAAuthorizedonetitle`, `CAAuthorizedtwo`, `CAAuthorizedtwoname`, `CAAuthorizedtwotitle`, `CAAuthorizedthree`, `CAAuthorizedthreename`, `CAAuthorizedthreetitle`, `CAAuthorizedfour`, `CAAuthorizedfourname`, `CAAuthorizedfourtitle`, `CAProofOfPayment`, `POADate`, `POAFirstName`, `POALastName`, `POACompanyName`, `POACompanyNumber`, `POACompanyCountry`, `POACompanyAddress`, `POACompanyCity`, `POACompanyState`, `POAAppointor`, `POAAppointorIdNumber`, `POACorporateSeal`, `POADirectorName`, `POADirectorSign`, `POASecretaryName`, `POASecretarySign`) VALUES
(10026, 100078, '', 'Artemyo Molave', 'Mumbai', 953, 0, 0, 0, 0, 0, 0, 'asdfghjkl', 'asdfghjk', 'Y', 0, 960, 1226, 962, 963, 964, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, '', '', 0, '', '', 0, '', '', 0, '1969-12-31', '', '', '', '', 'China', '', '', '', '', '', 0, '', 0, '', 0),
(10027, 100079, '', 'asdffsadfsdf', 'asdfasdfasdfasdf', 1184, 0, 0, 0, 0, 0, 0, 'asdfsadf', 'assdafsadf', 'Y', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, '', '', 0, '', '', 0, '', '', 0, '2016-11-10', 'Ryma', 'Bahho', 'CA Websol', '234567890', 'China', 'Manosita, Cacha Zhengui', 'Tzufo', 'Tsungo', 'Timacha', '9393939393', 1181, '', 1182, '', 1183);

-- --------------------------------------------------------

--
-- Table structure for table `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `BankAccountID` int(21) NOT NULL,
  `UserID` int(21) NOT NULL,
  `Address` varchar(128) NOT NULL,
  `SwiftCode` varchar(64) NOT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Name` varchar(64) NOT NULL,
  `AccountNumber` varchar(32) NOT NULL,
  `AccountName` varchar(64) NOT NULL,
  `TrustAccount` varchar(3) NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_accounts`
--

INSERT INTO `bank_accounts` (`BankAccountID`, `UserID`, `Address`, `SwiftCode`, `DateAdded`, `Name`, `AccountNumber`, `AccountName`, `TrustAccount`) VALUES
(9, 100024, 'SM Dasma', '987', '2016-07-11 05:23:15', 'BPI', '1692536417785', 'Motul Limpao', 'N'),
(17, 100033, 'Carmona', '3641', '2016-07-12 09:02:49', 'Metrobank', '3125469857', 'Fred Simpson', 'N'),
(20, 100037, 'GMA', '467', '2016-07-29 08:23:48', 'Bank of the Philippine Islands', '9865325689784512', 'Levy Powel', 'N'),
(21, 100039, 'Ortigas', '458', '2016-07-29 08:26:54', 'Asia United Bank', '963852741852852', 'Mark Goloyugo', 'N'),
(22, 100040, 'Wanderlei', '3125', '2016-08-02 09:09:14', 'China Bank', '800005274196374', 'Momo Kamo', 'N'),
(25, 100043, 'Saba Malaysia', '124', '2016-08-03 22:30:58', 'Bank of Malaysia', '65200021123456789', 'Atarma Mutarwi', 'N'),
(26, 100044, 'asdf', 'sadf', '2016-08-12 09:24:50', 'asdf', 'sadf', 'sadf', 'N'),
(27, 100045, 'adsf', 'sdaf', '2016-09-05 18:13:06', 'asdf', 'sadf', 'sdf', 'N'),
(28, 100047, 'hgfd', '123', '2016-09-05 18:27:11', 'Bank of the Philippine Islands', '9865325689784512', 'Fred Simpson', 'N'),
(30, 100049, 'sadf', 'sdaf', '2016-09-05 19:26:25', 'sadf', 'sdaf', 'sdaf', 'N'),
(31, 100050, 'asdfsadf', 'sadf', '2016-09-06 05:47:27', 'asdf', 'asdfasdf', 'asdf', 'N'),
(32, 100052, 'dasdsad', '23232', '2016-10-04 16:05:23', 'dasdasdsa', '23232', 'sdsasdasd', 'N'),
(33, 100053, 'dsads', '232', '2016-10-04 16:16:37', 'sadasd', '23232', 'dsadsa', 'N'),
(34, 100054, 'dsads', '232', '2016-10-04 16:20:34', 'sadasd', '23232', 'dsadsa', 'N'),
(35, 100055, 'dsad', '232', '2016-10-04 16:21:21', 'asdasd', '3232', 'sadasd', 'N'),
(36, 100056, 'asdas', '232', '2016-10-04 16:29:32', 'dasdasd', '2323', 'asdasd', 'N'),
(37, 100057, 'asdas', '232', '2016-10-04 16:35:31', 'dasdasd', '2323', 'asdasd', 'N'),
(38, 100058, 'asdas', '232', '2016-10-04 16:35:43', 'dasdasd', '2323', 'asdasd', 'N'),
(39, 100059, 'asdas', '232', '2016-10-04 16:37:13', 'dasdasd', '2323', 'asdasd', 'N'),
(40, 100060, 'sdasd', '3232', '2016-10-04 16:37:58', 'sad', '23232', 'dsad', 'N'),
(41, 100061, 'sadas', '232', '2016-10-04 16:46:49', 'dasdasda', '23232', 'dsadas', 'N'),
(42, 100062, 'sadas', '232', '2016-10-04 16:50:35', 'dasdasda', '23232', 'dsadas', 'N'),
(43, 100063, 'sadas', '232', '2016-10-04 16:50:43', 'dasdasda', '23232', 'dsadas', 'N'),
(44, 100064, 'sadas', '232', '2016-10-04 16:51:54', 'dasdasda', '23232', 'dsadas', 'N'),
(45, 100065, 'sadas', '232', '2016-10-04 16:53:20', 'dasdasda', '23232', 'dsadas', 'N'),
(46, 100066, 'dsadsa', '3232', '2016-10-04 16:54:09', 'dsadas', '2323', 'dsadasd', 'N'),
(47, 100067, 'dsadas', '2323', '2016-10-04 17:02:45', 'dasdasdasd', '323232', 'asdasdasdsa', 'N'),
(48, 100068, 'dsadas', '2323', '2016-10-04 17:09:33', 'dasdasdasd', '323232', 'asdasdasdsa', 'N'),
(49, 100069, 'dsadas', '2323', '2016-10-04 17:13:15', 'dasdasdasd', '323232', 'asdasdasdsa', 'N'),
(51, 100071, 'asda', 'asdas', '2016-10-04 17:20:46', 'sdasd', 'asdasdas', 'asd', 'N'),
(52, 100072, 'sadasda', 'adas', '2016-10-04 17:27:08', 'sdas', 'dasd', 'sda', 'N'),
(53, 100073, 'qwerty', 'qwerty', '2016-10-04 18:12:06', 'qwerty', 'qwerty', 'qwerty', 'N'),
(54, 100074, 'qwe', '123', '2016-10-10 10:46:53', 'qwe', '123', 'qwe', 'N'),
(55, 100075, 'Casile', '124', '2016-10-11 07:45:51', 'Asia United Bank', '12000369852147', 'Artemyo Molave', 'N'),
(56, 100076, 'Casile', '124', '2016-10-11 07:50:19', 'Asia United Bank', '12000369852147', 'Artemyo Molave', 'N'),
(57, 100077, 'Casile', '124', '2016-10-11 07:52:44', 'Asia United Bank', '12000369852147', 'Artemyo Molave', 'N'),
(58, 100078, 'Casile', '124', '2016-10-11 08:00:58', 'Asia United Bank', '12000369852147', 'Artemyo Molave', 'N'),
(59, 100079, 'asdf', 'sadf', '2016-10-11 12:45:44', 'sdaf', 'sdf', 'sdafsadf', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `FileID` int(21) NOT NULL,
  `UserID` int(21) NOT NULL,
  `DateAdded` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`FileID`, `UserID`, `DateAdded`) VALUES
(16, 100040, '2016-09-04 23:49:33'),
(17, 100040, '2016-09-04 23:49:33'),
(18, 100040, '2016-09-04 23:49:33'),
(19, 100040, '2016-09-04 23:49:33'),
(20, 100040, '2016-09-04 23:49:33'),
(21, 100040, '2016-09-04 23:49:33'),
(22, 100040, '2016-09-04 23:49:33'),
(23, 100040, '2016-09-04 23:49:33'),
(24, 100040, '2016-09-04 23:49:33'),
(25, 100040, '2016-09-04 23:49:33'),
(26, 100040, '2016-09-04 23:49:33'),
(27, 100040, '2016-09-04 23:49:33'),
(28, 100040, '2016-09-04 23:49:33'),
(29, 100040, '2016-09-04 23:49:33'),
(30, 100040, '2016-09-04 23:49:33'),
(31, 100040, '2016-09-04 23:49:33'),
(32, 100040, '2016-09-04 23:49:33'),
(33, 100040, '2016-09-04 23:49:33'),
(34, 100040, '2016-09-04 23:49:33'),
(35, 100040, '2016-09-04 23:49:33'),
(36, 100040, '2016-09-04 23:49:33'),
(37, 100040, '2016-09-04 23:49:33'),
(38, 100040, '2016-09-04 23:49:33'),
(39, 100040, '2016-09-04 23:49:33'),
(40, 100040, '2016-09-04 23:49:33'),
(41, 100040, '2016-09-04 23:49:33'),
(42, 100040, '2016-09-04 23:49:33'),
(43, 100040, '2016-09-04 23:49:33'),
(44, 100040, '2016-09-04 23:49:33'),
(45, 100040, '2016-09-04 23:49:33'),
(55, 100043, '2016-09-05 00:56:21'),
(76, 100043, '2016-09-05 00:56:58'),
(110, 100043, '2016-09-05 00:57:36'),
(167, 100046, '2016-09-05 11:18:00'),
(175, 100047, '2016-09-05 11:27:11'),
(178, 100047, '2016-09-05 11:27:11'),
(179, 100047, '2016-09-05 11:27:11'),
(180, 100047, '2016-09-05 11:27:11'),
(181, 100047, '2016-09-05 11:27:11'),
(202, 100048, '2016-09-05 12:02:30'),
(209, 100048, '2016-09-05 12:02:30'),
(210, 100048, '2016-09-05 12:02:30'),
(211, 100048, '2016-09-05 12:02:30'),
(212, 100048, '2016-09-05 12:02:30'),
(233, 100049, '2016-09-05 12:26:25'),
(240, 100049, '2016-09-05 12:26:25'),
(241, 100049, '2016-09-05 12:26:25'),
(242, 100049, '2016-09-05 12:26:25'),
(243, 100049, '2016-09-05 12:26:25'),
(304, 100049, '2016-09-05 21:58:00'),
(322, 100050, '2016-09-05 22:47:27'),
(323, 100050, '2016-09-05 22:47:27'),
(324, 100050, '2016-09-05 22:47:27'),
(328, 100050, '2016-09-05 22:47:27'),
(696, 100049, '2016-09-06 10:48:17'),
(732, 100049, '2016-09-06 11:00:35'),
(733, 0, '2016-09-14 04:11:08'),
(734, 0, '2016-09-14 04:12:20'),
(735, 0, '2016-09-14 04:12:49'),
(736, 0, '2016-09-14 04:17:38'),
(737, 0, '2016-09-14 04:17:43'),
(738, 0, '2016-09-14 04:18:37'),
(739, 0, '2016-09-14 04:21:07'),
(740, 0, '2016-09-14 04:38:23'),
(741, 0, '2016-09-14 04:38:40'),
(742, 0, '2016-09-14 04:38:47'),
(743, 0, '2016-09-14 04:40:32'),
(746, 0, '2016-09-14 04:54:56'),
(754, 0, '2016-09-21 08:35:15'),
(756, 0, '2016-09-21 08:35:27'),
(758, 0, '2016-09-21 08:35:38'),
(768, 0, '2016-09-21 08:49:20'),
(770, 0, '2016-09-21 08:49:54'),
(776, 0, '2016-09-21 08:54:30'),
(785, 0, '2016-09-21 09:11:53'),
(787, 0, '2016-09-21 09:12:17'),
(789, 0, '2016-09-21 09:12:57'),
(793, 0, '2016-09-21 09:13:44'),
(795, 0, '2016-09-21 09:14:15'),
(797, 0, '2016-09-21 09:15:00'),
(799, 0, '2016-09-21 09:15:46'),
(801, 0, '2016-09-21 09:16:29'),
(803, 0, '2016-09-21 09:16:38'),
(805, 0, '2016-09-21 09:19:41'),
(807, 0, '2016-09-21 09:19:53'),
(809, 0, '2016-09-21 09:21:07'),
(811, 0, '2016-09-21 09:22:59'),
(813, 0, '2016-09-21 09:24:53'),
(815, 0, '2016-09-21 09:32:22'),
(817, 0, '2016-09-21 09:33:28'),
(819, 0, '2016-09-21 09:33:46'),
(821, 0, '2016-09-21 09:34:10'),
(823, 0, '2016-09-21 09:35:28'),
(826, 0, '2016-09-22 02:58:33'),
(828, 0, '2016-09-22 03:09:57'),
(830, 0, '2016-09-22 03:10:00'),
(832, 0, '2016-09-22 03:12:18'),
(834, 0, '2016-09-22 03:13:49'),
(836, 0, '2016-09-22 03:15:19'),
(839, 0, '2016-09-22 03:20:41'),
(840, 0, '2016-09-22 03:40:42'),
(843, 0, '2016-09-22 04:41:20'),
(845, 0, '2016-09-22 04:41:23'),
(847, 0, '2016-09-22 04:41:32'),
(848, 100051, '2016-09-26 04:03:56'),
(849, 100037, '2016-10-10 12:45:13'),
(854, 100075, '2016-10-11 00:45:51'),
(861, 100075, '2016-10-11 00:45:51'),
(862, 100075, '2016-10-11 00:45:51'),
(863, 100075, '2016-10-11 00:45:51'),
(864, 100075, '2016-10-11 00:45:51'),
(865, 100075, '2016-10-11 00:45:51'),
(887, 100076, '2016-10-11 00:50:19'),
(894, 100076, '2016-10-11 00:50:19'),
(895, 100076, '2016-10-11 00:50:19'),
(896, 100076, '2016-10-11 00:50:19'),
(897, 100076, '2016-10-11 00:50:19'),
(898, 100076, '2016-10-11 00:50:19'),
(920, 100077, '2016-10-11 00:52:44'),
(927, 100077, '2016-10-11 00:52:44'),
(928, 100077, '2016-10-11 00:52:44'),
(929, 100077, '2016-10-11 00:52:44'),
(930, 100077, '2016-10-11 00:52:44'),
(931, 100077, '2016-10-11 00:52:44'),
(953, 100078, '2016-10-11 01:00:59'),
(960, 100078, '2016-10-11 01:00:59'),
(961, 100078, '2016-10-11 01:00:59'),
(962, 100078, '2016-10-11 01:00:59'),
(963, 100078, '2016-10-11 01:00:59'),
(964, 100078, '2016-10-11 01:00:59'),
(1181, 100079, '2016-10-11 05:45:44'),
(1182, 100079, '2016-10-11 05:45:44'),
(1183, 100079, '2016-10-11 05:45:44'),
(1184, 100079, '2016-10-11 05:45:44'),
(1226, 100078, '2016-10-11 05:56:56'),
(1229, 0, '2016-10-30 09:49:08'),
(1230, 0, '2016-10-30 09:49:37'),
(1232, 100000, '2016-10-30 12:18:58'),
(1233, 100000, '2016-10-30 22:04:48'),
(1234, 100000, '2016-10-30 22:06:00'),
(1240, 100000, '2016-10-31 00:44:27'),
(1241, 100000, '2016-10-31 00:44:27'),
(1242, 100000, '2016-10-31 00:45:07'),
(1243, 100000, '2016-10-31 00:45:07'),
(1244, 100000, '2016-10-31 00:48:37'),
(1245, 100000, '2016-10-31 00:48:37'),
(1246, 100000, '2016-10-31 00:49:21'),
(1247, 100000, '2016-10-31 00:49:21'),
(1248, 100000, '2016-10-31 00:51:14'),
(1249, 100000, '2016-10-31 00:51:14'),
(1250, 100000, '2016-10-31 00:52:04'),
(1251, 100000, '2016-10-31 00:52:04'),
(1252, 100000, '2016-10-31 01:14:28'),
(1253, 100000, '2016-10-31 01:14:28'),
(1254, 100000, '2016-10-31 01:14:28'),
(1271, 100000, '2016-10-31 01:41:11'),
(1275, 100000, '2016-10-31 01:41:36'),
(1277, 100000, '2016-10-31 01:42:40'),
(1278, 100000, '2016-10-31 01:42:40');

-- --------------------------------------------------------

--
-- Table structure for table `file_items`
--

CREATE TABLE `file_items` (
  `FileItemID` int(21) NOT NULL,
  `UserID` int(21) NOT NULL,
  `FileID` int(21) NOT NULL,
  `FileDescription` varchar(64) NOT NULL,
  `FileName` text NOT NULL,
  `FilePath` text NOT NULL,
  `FileSlug` varchar(512) NOT NULL,
  `Active` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `file_items`
--

INSERT INTO `file_items` (`FileItemID`, `UserID`, `FileID`, `FileDescription`, `FileName`, `FilePath`, `FileSlug`, `Active`) VALUES
(15, 100000, 11, 'Avatar', '656ea727_trio.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\02\\656ea727_trio.jpg', '/2016/09/02/656ea727_trio.jpg', 1),
(16, 100000, 12, 'Avatar', '3ddab30d_web.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\02\\3ddab30d_web.jpg', '/2016/09/02/3ddab30d_web.jpg', 1),
(17, 100000, 13, 'Avatar', 'cd5601a2_portrait.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\02\\cd5601a2_portrait.jpg', '/2016/09/02/cd5601a2_portrait.jpg', 1),
(20, 100040, 17, 'UBOEmploymentIncome', '642a9306_test.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\04\\642a9306_test.jpg', '/2016/09/04/642a9306_test.jpg', 0),
(21, 100040, 25, 'IAPhotoid', 'd0fa7b70_test.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\04\\d0fa7b70_test.jpg', '/2016/09/04/d0fa7b70_test.jpg', 1),
(22, 100040, 26, 'IAProofresidency', 'Purefoods', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\04\\1b87d1ee_test.jpg', '/2016/09/04/1b87d1ee_test.jpg', 1),
(23, 100040, 27, 'IABankstatement', 'caf27d6a_test.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\04\\caf27d6a_test.jpg', '/2016/09/04/caf27d6a_test.jpg', 1),
(24, 100040, 28, 'IASpecimensign', '5b81021d_test.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\04\\5b81021d_test.jpg', '/2016/09/04/5b81021d_test.jpg', 0),
(25, 100043, 55, 'IAPhotoid', '24bbf8f7_portrait.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\24bbf8f7_portrait.jpg', '/2016/09/05/24bbf8f7_portrait.jpg', 1),
(26, 100043, 76, 'BeneficiariesForm', '8c42ab3c_banner.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\8c42ab3c_banner.png', '/2016/09/05/8c42ab3c_banner.png', 0),
(27, 100043, 110, 'UBOInheritance', '5b0f3b6f_logo.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\5b0f3b6f_logo.png', '/2016/09/05/5b0f3b6f_logo.png', 0),
(28, 100046, 167, 'Avatar', 'ffd367d5_shine.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\ffd367d5_shine.png', '/2016/09/05/ffd367d5_shine.png', 1),
(29, 100047, 175, 'UBOGift', 'c449ddc2_banner.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\c449ddc2_banner.png', '/2016/09/05/c449ddc2_banner.png', 1),
(30, 100047, 178, 'IAPhotoid', 'f7613e53_banner.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\f7613e53_banner.png', '/2016/09/05/f7613e53_banner.png', 1),
(31, 100047, 179, 'IAProofresidency', '5bacf84f_banner.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\5bacf84f_banner.png', '/2016/09/05/5bacf84f_banner.png', 1),
(32, 100047, 180, 'IABankstatement', 'e72e3323_banner.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\e72e3323_banner.png', '/2016/09/05/e72e3323_banner.png', 1),
(33, 100047, 181, 'IASpecimensign', 'fc855f14_banner.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\fc855f14_banner.png', '/2016/09/05/fc855f14_banner.png', 0),
(34, 100048, 202, 'UBOEmploymentIncome', 'cff6e379_profile.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\cff6e379_profile.jpg', '/2016/09/05/cff6e379_profile.jpg', 1),
(35, 100048, 209, 'IAPhotoid', '884c109a_IMG_2984.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\884c109a_IMG_2984.jpg', '/2016/09/05/884c109a_IMG_2984.jpg', 1),
(36, 100048, 210, 'IAProofresidency', 'c72d3844_IMG_3679.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\c72d3844_IMG_3679.jpg', '/2016/09/05/c72d3844_IMG_3679.jpg', 0),
(37, 100048, 211, 'IABankstatement', 'da0a8b8e_P_20150101_031347.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\da0a8b8e_P_20150101_031347.jpg', '/2016/09/05/da0a8b8e_P_20150101_031347.jpg', 1),
(38, 100048, 212, 'IASpecimensign', 'f1d7082f_lumapitka.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\f1d7082f_lumapitka.jpg', '/2016/09/05/f1d7082f_lumapitka.jpg', 1),
(39, 100049, 233, 'UBOEmploymentIncome', '87f3097c_profile.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\87f3097c_profile.jpg', '/2016/09/05/87f3097c_profile.jpg', 2),
(40, 100049, 240, 'PhotoID', 'Aliya', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\0f1fc10a_IMG_2984.jpg', '/2016/09/05/0f1fc10a_IMG_2984.jpg', 1),
(41, 100049, 241, 'IAProofresidency', '2bec5155_IMG_3679.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\2bec5155_IMG_3679.jpg', '/2016/09/05/2bec5155_IMG_3679.jpg', 1),
(42, 100049, 242, 'IABankstatement', '51783cc0_P_20150101_031347.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\51783cc0_P_20150101_031347.jpg', '/2016/09/05/51783cc0_P_20150101_031347.jpg', 1),
(45, 100050, 322, 'POACorporateSeal', '610ab5b0_aliyah.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\610ab5b0_aliyah.jpg', '/2016/09/05/610ab5b0_aliyah.jpg', 0),
(46, 100050, 323, 'POADirectorSign', 'd881293a_aliyah.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\d881293a_aliyah.jpg', '/2016/09/05/d881293a_aliyah.jpg', 0),
(47, 100050, 324, 'POASecretarySign', 'd011878f_aliyah.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\d011878f_aliyah.jpg', '/2016/09/05/d011878f_aliyah.jpg', 0),
(48, 100050, 328, 'UBOInheritance', 'af8853f3_aliyah.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\05\\af8853f3_aliyah.jpg', '/2016/09/05/af8853f3_aliyah.jpg', 0),
(49, 100049, 696, 'IAPhotoid', 'ed7431fa_sevices2.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\06\\ed7431fa_sevices2.jpg', '/2016/09/06/ed7431fa_sevices2.jpg', 0),
(51, 100049, 732, 'IASpecimensign', '8ca659fb_aliyah.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\09\\06\\8ca659fb_aliyah.jpg', '/2016/09/06/8ca659fb_aliyah.jpg', 0),
(52, 0, 733, 'Favicon', 'c91e5c7a_Philippine-1000-Peso.jpeg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\14\\c91e5c7a_Philippine-1000-Peso.jpeg', '/2016/09/14/c91e5c7a_Philippine-1000-Peso.jpeg', 0),
(53, 0, 734, 'Favicon', '129a204d_Philippine-1000-Peso.jpeg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\14\\129a204d_Philippine-1000-Peso.jpeg', '/2016/09/14/129a204d_Philippine-1000-Peso.jpeg', 0),
(54, 0, 735, 'Favicon', '4432c70d_Philippine-1000-Peso.jpeg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\14\\4432c70d_Philippine-1000-Peso.jpeg', '/2016/09/14/4432c70d_Philippine-1000-Peso.jpeg', 0),
(55, 0, 736, 'Favicon', '2c6e81a8_Philippine-1000-Peso.jpeg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\14\\2c6e81a8_Philippine-1000-Peso.jpeg', '/2016/09/14/2c6e81a8_Philippine-1000-Peso.jpeg', 0),
(56, 0, 737, 'Favicon', '9bd71b4a_Philippine-1000-Peso.jpeg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\14\\9bd71b4a_Philippine-1000-Peso.jpeg', '/2016/09/14/9bd71b4a_Philippine-1000-Peso.jpeg', 0),
(57, 0, 738, 'Favicon', '6e86a0a0_Philippine-1000-Peso.jpeg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\14\\6e86a0a0_Philippine-1000-Peso.jpeg', '/2016/09/14/6e86a0a0_Philippine-1000-Peso.jpeg', 0),
(58, 0, 739, 'Favicon', 'ff1f9c42_Philippine-1000-Peso.jpeg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\14\\ff1f9c42_Philippine-1000-Peso.jpeg', '/2016/09/14/ff1f9c42_Philippine-1000-Peso.jpeg', 0),
(59, 0, 740, 'Favicon', '5b0d2332_Philippine-1000-Peso.jpeg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\14\\5b0d2332_Philippine-1000-Peso.jpeg', '/2016/09/14/5b0d2332_Philippine-1000-Peso.jpeg', 0),
(60, 0, 741, 'Favicon', 'c2361de2_Philippine-1000-Peso.jpeg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\14\\c2361de2_Philippine-1000-Peso.jpeg', '/2016/09/14/c2361de2_Philippine-1000-Peso.jpeg', 0),
(61, 0, 742, 'Favicon', '7dc731b0_Philippine-1000-Peso.jpeg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\14\\7dc731b0_Philippine-1000-Peso.jpeg', '/2016/09/14/7dc731b0_Philippine-1000-Peso.jpeg', 0),
(62, 0, 743, 'Favicon', '9e57a901_Philippine-1000-Peso.jpeg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\14\\9e57a901_Philippine-1000-Peso.jpeg', '/2016/09/14/9e57a901_Philippine-1000-Peso.jpeg', 0),
(64, 0, 746, 'Logo', 'b7844924_Philippine-1000-Peso.jpeg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\14\\b7844924_Philippine-1000-Peso.jpeg', '/2016/09/14/b7844924_Philippine-1000-Peso.jpeg', 0),
(70, 0, 754, 'Favicon', '178d7dc0_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\178d7dc0_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/178d7dc0_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(71, 0, 756, 'Favicon', '7e8b0253_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\7e8b0253_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/7e8b0253_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(72, 0, 758, 'Favicon', 'bec3bb01_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\bec3bb01_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/bec3bb01_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(77, 0, 768, 'Favicon', 'bf0a80e4_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\bf0a80e4_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/bf0a80e4_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(78, 0, 770, 'Favicon', '97d4b456_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\97d4b456_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/97d4b456_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(81, 0, 776, 'Favicon', '5622b0bf_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\5622b0bf_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/5622b0bf_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(86, 0, 785, 'Logo', '5edcd20f_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\5edcd20f_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/5edcd20f_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(87, 0, 787, 'Logo', '84560b39_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\84560b39_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/84560b39_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(88, 0, 789, 'Logo', '311a1973_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\311a1973_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/311a1973_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(90, 0, 793, 'Logo', '0f26b887_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\0f26b887_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/0f26b887_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(91, 0, 795, 'Logo', 'fee4662e_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\fee4662e_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/fee4662e_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(92, 0, 797, 'Logo', 'c3d480ff_96215644_images.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\c3d480ff_96215644_images.jpg', '/2016/09/21/c3d480ff_96215644_images.jpg', 0),
(93, 0, 799, 'Logo', 'c01183b5_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\c01183b5_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/c01183b5_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(94, 0, 801, 'Logo', '4d30b829_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\4d30b829_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/4d30b829_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(95, 0, 803, 'Logo', 'c57c72a3_02758f6e_20130719_205310.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\c57c72a3_02758f6e_20130719_205310.jpg', '/2016/09/21/c57c72a3_02758f6e_20130719_205310.jpg', 0),
(96, 0, 805, 'Logo', '60900c47_02758f6e_20130719_205310.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\60900c47_02758f6e_20130719_205310.jpg', '/2016/09/21/60900c47_02758f6e_20130719_205310.jpg', 0),
(97, 0, 807, 'Logo', '3c18c82e_02758f6e_20130719_205310.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\3c18c82e_02758f6e_20130719_205310.jpg', '/2016/09/21/3c18c82e_02758f6e_20130719_205310.jpg', 0),
(98, 0, 809, 'Logo', 'f3045d75_02758f6e_20130719_205310.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\f3045d75_02758f6e_20130719_205310.jpg', '/2016/09/21/f3045d75_02758f6e_20130719_205310.jpg', 0),
(99, 0, 811, 'Logo', '69e2c997_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\69e2c997_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/69e2c997_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(100, 0, 813, 'Logo', '25dcb8d4_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\25dcb8d4_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', '/2016/09/21/25dcb8d4_5436dc60_8ACD97AC-0A98-43BA-AE4D-A7CFB3AD66CF.jpg', 0),
(101, 0, 815, 'Logo', '0510c360_logo.png', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\0510c360_logo.png', '/2016/09/21/0510c360_logo.png', 0),
(102, 0, 817, 'Logo', '4e08de34_logo.png', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\4e08de34_logo.png', '/2016/09/21/4e08de34_logo.png', 0),
(103, 0, 819, 'Logo', '01e6ccbb_logo-s.png', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\01e6ccbb_logo-s.png', '/2016/09/21/01e6ccbb_logo-s.png', 0),
(104, 0, 821, 'Logo', '7a479419_logo-s.png', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\7a479419_logo-s.png', '/2016/09/21/7a479419_logo-s.png', 0),
(105, 0, 823, 'Logo', '0de27913_logo.png', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\21\\0de27913_logo.png', '/2016/09/21/0de27913_logo.png', 0),
(107, 0, 826, 'Logo', 'c6065a91_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\22\\c6065a91_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', '/2016/09/22/c6065a91_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 0),
(108, 0, 828, 'Logo', '105c1aad_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\22\\105c1aad_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', '/2016/09/22/105c1aad_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 0),
(109, 0, 830, 'Logo', '962e21a2_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\22\\962e21a2_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', '/2016/09/22/962e21a2_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 0),
(110, 0, 832, 'Logo', '05c3ce69_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\22\\05c3ce69_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', '/2016/09/22/05c3ce69_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 0),
(111, 0, 834, 'Logo', 'b462ebc8_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\22\\b462ebc8_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', '/2016/09/22/b462ebc8_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 0),
(112, 0, 836, 'Logo', 'e7c36154_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\22\\e7c36154_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', '/2016/09/22/e7c36154_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 0),
(113, 0, 839, 'Favicon', '9c5f847d_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\22\\9c5f847d_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', '/2016/09/22/9c5f847d_1be0268b_7d6be368a17e7bdf308a0225b4ca9eb6.jpg', 0),
(114, 0, 840, 'Logo', '7ad1a384_01e6ccbb_logo-s.png', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\22\\7ad1a384_01e6ccbb_logo-s.png', '/2016/09/22/7ad1a384_01e6ccbb_logo-s.png', 0),
(115, 0, 843, 'Favicon', '5580fe9e_7a479419_logo-s.png', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\22\\5580fe9e_7a479419_logo-s.png', '/2016/09/22/5580fe9e_7a479419_logo-s.png', 0),
(116, 0, 845, 'Favicon', 'fe33656a_7a479419_logo-s.png', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\22\\fe33656a_7a479419_logo-s.png', '/2016/09/22/fe33656a_7a479419_logo-s.png', 0),
(117, 0, 847, 'Favicon', 'cb59d8e3_7a479419_logo-s.png', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\22\\cb59d8e3_7a479419_logo-s.png', '/2016/09/22/cb59d8e3_7a479419_logo-s.png', 0),
(118, 100051, 848, 'Avatar', '911ff939_ryan.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\09\\26\\911ff939_ryan.jpg', '/2016/09/26/911ff939_ryan.jpg', 0),
(119, 100037, 849, 'Avatar', 'ec2fbdbd_4.jpg', 'C:\\xampp\\htdocs\\odeonco.loc\\app\\views\\default\\assets\\files\\2016\\10\\10\\ec2fbdbd_4.jpg', '/2016/10/10/ec2fbdbd_4.jpg', 0),
(121, 100075, 854, 'UBOEmploymentIncome', 'e05da9bb_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\e05da9bb_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/e05da9bb_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(122, 100075, 861, 'IAPhotoid', 'e28fb2bb_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\e28fb2bb_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/e28fb2bb_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(123, 100075, 862, 'IAProofresidency', 'fb792683_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\fb792683_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/fb792683_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(124, 100075, 863, 'IABankstatement', 'fbcbf49c_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\fbcbf49c_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/fbcbf49c_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(125, 100075, 864, 'IASpecimensign', '068e8112_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\068e8112_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/068e8112_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(126, 100075, 865, 'IAProofOfPayment', '0a9b323b_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\0a9b323b_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/0a9b323b_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(127, 100076, 887, 'UBOEmploymentIncome', '654f0f93_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\654f0f93_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/654f0f93_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(128, 100076, 894, 'IAPhotoid', 'b3e5b337_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\b3e5b337_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/b3e5b337_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(129, 100076, 895, 'IAProofresidency', '922a2ac2_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\922a2ac2_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/922a2ac2_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(130, 100076, 896, 'IABankstatement', '1db6e934_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\1db6e934_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/1db6e934_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(131, 100076, 897, 'IASpecimensign', '3eb3a240_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\3eb3a240_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/3eb3a240_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(132, 100076, 898, 'IAProofOfPayment', '6b676ae6_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\6b676ae6_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/6b676ae6_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(133, 100077, 920, 'UBOEmploymentIncome', '1bfa02d9_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\1bfa02d9_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/1bfa02d9_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(134, 100077, 927, 'IAPhotoid', 'ff729c34_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\ff729c34_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/ff729c34_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(135, 100077, 928, 'IAProofresidency', '4fc9ff15_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\4fc9ff15_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/4fc9ff15_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(136, 100077, 929, 'IABankstatement', '571248f0_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\571248f0_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/571248f0_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(137, 100077, 930, 'IASpecimensign', 'de87a884_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\de87a884_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/de87a884_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(138, 100077, 931, 'IAProofOfPayment', '00d36612_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\00d36612_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/00d36612_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(139, 100078, 953, 'UBOEmploymentIncome', '2d50d3fe_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\2d50d3fe_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/2d50d3fe_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(143, 100078, 963, 'IASpecimensign', 'a290c4d2_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\a290c4d2_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/a290c4d2_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 2),
(144, 100078, 964, 'IAProofOfPayment', '25480a13_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\25480a13_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/25480a13_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(145, 100079, 1181, 'POACorporateSeal', '736cbfdf_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\736cbfdf_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/736cbfdf_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(146, 100079, 1182, 'POADirectorSign', '919da4ec_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\919da4ec_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/919da4ec_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(147, 100079, 1183, 'POASecretarySign', 'c841845e_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\c841845e_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/c841845e_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(148, 100079, 1184, 'UBOEmploymentIncome', '9e7884cc_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\9e7884cc_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', '/2016/10/11/9e7884cc_^FAD6ED0475C139ED3681F8F8A95214B00AE4E3B0E8F4D4E55D^pimgpsh_fullsize_distr.jpg', 0),
(149, 100078, 1226, 'IAProofresidency', 'a3af71ed_IMG_20151203_001140.jpg', 'E:\\Mo\\htdocs\\odeonco\\app\\views\\default\\assets\\files\\2016\\10\\11\\a3af71ed_IMG_20151203_001140.jpg', '/2016/10/11/a3af71ed_IMG_20151203_001140.jpg', 1),
(151, 0, 1229, 'Favicon', '3b6c1682_IMG_20160429_071702_1.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\30\\3b6c1682_IMG_20160429_071702_1.jpg', '/2016/10/30/3b6c1682_IMG_20160429_071702_1.jpg', 0),
(152, 0, 1230, 'Logo', '79c03362_giant.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\30\\79c03362_giant.jpg', '/2016/10/30/79c03362_giant.jpg', 0),
(153, 100000, 1232, 'Avatar', 'be317824_tier1.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\30\\be317824_tier1.png', '/2016/10/30/be317824_tier1.png', 0),
(154, 100000, 1233, 'Avatar', '9311af32_IMG_20151203_001140.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\30\\9311af32_IMG_20151203_001140.jpg', '/2016/10/30/9311af32_IMG_20151203_001140.jpg', 0),
(155, 100000, 1234, 'Avatar', 'e4af3a52_IMG_20151203_001140.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\30\\e4af3a52_IMG_20151203_001140.jpg', '/2016/10/30/e4af3a52_IMG_20151203_001140.jpg', 0),
(156, 100000, 1240, 'favicon', '35ce0d72_pallet.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\35ce0d72_pallet.jpg', '/2016/10/31/35ce0d72_pallet.jpg', 0),
(157, 100000, 1241, 'site_logo', 'c35862af_IMG_20151203_001140.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\c35862af_IMG_20151203_001140.jpg', '/2016/10/31/c35862af_IMG_20151203_001140.jpg', 0),
(158, 100000, 1242, 'favicon', '9956d2cd_pallet.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\9956d2cd_pallet.jpg', '/2016/10/31/9956d2cd_pallet.jpg', 0),
(159, 100000, 1243, 'site_logo', 'd8c5254e_IMG_20151203_001140.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\d8c5254e_IMG_20151203_001140.jpg', '/2016/10/31/d8c5254e_IMG_20151203_001140.jpg', 0),
(160, 100000, 1244, 'favicon', '13f4de87_pallet.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\13f4de87_pallet.jpg', '/2016/10/31/13f4de87_pallet.jpg', 0),
(161, 100000, 1245, 'site_logo', 'ff6696e6_IMG_20151203_001140.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\ff6696e6_IMG_20151203_001140.jpg', '/2016/10/31/ff6696e6_IMG_20151203_001140.jpg', 0),
(162, 100000, 1246, 'favicon', '3897230c_pallet.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\3897230c_pallet.jpg', '/2016/10/31/3897230c_pallet.jpg', 0),
(163, 100000, 1247, 'site_logo', 'babf4f73_IMG_20151203_001140.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\babf4f73_IMG_20151203_001140.jpg', '/2016/10/31/babf4f73_IMG_20151203_001140.jpg', 0),
(164, 100000, 1248, 'favicon', '7ae620d2_pallet.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\7ae620d2_pallet.jpg', '/2016/10/31/7ae620d2_pallet.jpg', 0),
(165, 100000, 1249, 'site_logo', '7c129ac2_IMG_20151203_001140.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\7c129ac2_IMG_20151203_001140.jpg', '/2016/10/31/7c129ac2_IMG_20151203_001140.jpg', 0),
(166, 100000, 1250, 'favicon', '91715edc_pallet.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\91715edc_pallet.jpg', '/2016/10/31/91715edc_pallet.jpg', 0),
(167, 100000, 1251, 'site_logo', 'aa39d33e_IMG_20151203_001140.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\aa39d33e_IMG_20151203_001140.jpg', '/2016/10/31/aa39d33e_IMG_20151203_001140.jpg', 0),
(168, 100000, 1252, 'favicon', 'e84bfdfc_logo-s.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\e84bfdfc_logo-s.png', '/2016/10/31/e84bfdfc_logo-s.png', 0),
(169, 100000, 1253, 'site_logo', 'e7b6bde6_logo.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\e7b6bde6_logo.png', '/2016/10/31/e7b6bde6_logo.png', 0),
(170, 100000, 1254, 'site_logo_small', 'a5279f2f_logo-s.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\a5279f2f_logo-s.png', '/2016/10/31/a5279f2f_logo-s.png', 0),
(171, 100000, 1271, 'site_logo', '9fca75d0_pallet.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\9fca75d0_pallet.jpg', '/2016/10/31/9fca75d0_pallet.jpg', 0),
(172, 100000, 1275, 'site_logo_small', 'f2a94655_IMG_20151203_001140.jpg', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\f2a94655_IMG_20151203_001140.jpg', '/2016/10/31/f2a94655_IMG_20151203_001140.jpg', 0),
(173, 100000, 1277, 'site_logo', '99882296_logo.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\99882296_logo.png', '/2016/10/31/99882296_logo.png', 0),
(174, 100000, 1278, 'site_logo_small', '48f149c6_logo-s.png', 'C:\\Bitnami\\wamp\\apache2\\htdocs\\odeonco\\app\\views\\odeon\\assets\\files\\2016\\10\\31\\48f149c6_logo-s.png', '/2016/10/31/48f149c6_logo-s.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `OptionID` int(11) NOT NULL,
  `OptionGroupID` int(11) NOT NULL,
  `OptionKey` varchar(512) NOT NULL,
  `OptionValue` longtext NOT NULL,
  `OptionLabel` varchar(512) NOT NULL,
  `FormType` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`OptionID`, `OptionGroupID`, `OptionKey`, `OptionValue`, `OptionLabel`, `FormType`) VALUES
(1, 1, 'site_title', 'Odeon & Co. ', 'Site Title', 'text'),
(2, 1, 'site_tagline', 'Odeon & Co. Trust Accounts System', 'Site Tagline', 'text'),
(3, 1, 'new_user_role', 'Client', 'New user role', 'select'),
(4, 1, 'time_zone', 'Asia/Singapore', 'Time Zone', 'select'),
(5, 1, 'site_language', 'cn', 'Site Language', 'select'),
(6, 2, 'role_redirects', 'YTo4OntpOjE7czoxOToiaHR0cDovL29kZW9uY28ubG9jLyI7aToyO3M6MTg6Imh0dHA6Ly9vZGVvbmNvLmxvYyI7aTozO3M6MjY6Imh0dHA6Ly9vZGVvbmNvLmxvYy9jbGllbnRzIjtpOjQ7czoyNjoiaHR0cDovL29kZW9uY28ubG9jL2NsaWVudHMiO2k6NTtzOjI2OiJodHRwOi8vb2Rlb25jby5sb2MvY2xpZW50cyI7aTo2O3M6MTg6Imh0dHA6Ly9vZGVvbmNvLmxvYyI7aTo3O3M6MTg6Imh0dHA6Ly9vZGVvbmNvLmxvYyI7aTo4O3M6MTg6Imh0dHA6Ly9vZGVvbmNvLmxvYyI7fQ==', 'Role Redirects', 'text_array'),
(7, 1, 'favicon', '1252', 'Favicon', 'upload'),
(8, 1, 'site_logo', '1277', 'Site Logo', 'upload'),
(10, 1, 'site_logo_small', '1278', 'Site Logo Small (Mobile)', 'upload');

-- --------------------------------------------------------

--
-- Table structure for table `option_groups`
--

CREATE TABLE `option_groups` (
  `OptionGroupID` int(11) NOT NULL,
  `GroupName` varchar(512) NOT NULL,
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `option_groups`
--

INSERT INTO `option_groups` (`OptionGroupID`, `GroupName`, `Description`) VALUES
(1, 'General', ''),
(2, 'Menu', ''),
(3, 'Mail', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ProductID` int(21) NOT NULL,
  `ProductName` varchar(128) NOT NULL,
  `ProductDescription` text NOT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ProductLabel` varchar(512) NOT NULL,
  `Active` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductID`, `ProductName`, `ProductDescription`, `DateAdded`, `ProductLabel`, `Active`) VALUES
(210001, 'Odeon Interest', 'Odeon Product 1 - Odeon Interest', '2016-09-12 06:28:45', '', 1),
(210002, 'Odeon Capital', 'Odeon Product 2 - Odeon Capital', '2016-09-12 17:53:07', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_items`
--

CREATE TABLE `product_items` (
  `ProductItemID` int(21) NOT NULL,
  `ProductID` int(21) NOT NULL,
  `InvestmentAmount` float DEFAULT NULL,
  `StepUp` float DEFAULT NULL,
  `DividendFrequency` int(11) DEFAULT NULL,
  `TenureMonths` int(11) DEFAULT NULL,
  `QuarterlyInterest` float DEFAULT NULL,
  `AnnualInterest` float DEFAULT NULL,
  `StateRepCommission` float NOT NULL,
  `CityRepCommission` float NOT NULL,
  `AgentCommission` float NOT NULL,
  `CoreTeamCommission` float NOT NULL,
  `LocalAgencyCommission` float NOT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ItemLabel` varchar(512) NOT NULL,
  `Active` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_items`
--

INSERT INTO `product_items` (`ProductItemID`, `ProductID`, `InvestmentAmount`, `StepUp`, `DividendFrequency`, `TenureMonths`, `QuarterlyInterest`, `AnnualInterest`, `StateRepCommission`, `CityRepCommission`, `AgentCommission`, `CoreTeamCommission`, `LocalAgencyCommission`, `DateAdded`, `ItemLabel`, `Active`) VALUES
(10035, 210002, 1000000, 100000, 12, 36, 12, 0, 10, 8, 6, 11.5, 14, '2016-09-23 07:45:28', '0', 1),
(10034, 210002, 500000, 100000, 12, 36, 0, 11, 10, 8, 6, 11.5, 14, '2016-09-23 07:44:52', '0', 1),
(10033, 210002, 300000, 50000, 12, 36, 0, 10, 9, 7.2, 5.4, 11.5, 14, '2016-09-23 07:44:19', '0', 1),
(10032, 210002, 100000, 50000, 12, 24, 0, 8.5, 8, 6.4, 4.8, 11.5, 14, '2016-09-23 07:43:48', '0', 1),
(10031, 210002, 50000, 10000, 12, 24, 0, 8, 8, 6.4, 4.8, 11.5, 14, '2016-09-23 07:43:14', '0', 1),
(10030, 210002, 20000, 10000, 12, 24, 0, 8, 8, 6.4, 4.8, 11.5, 14, '2016-09-23 07:42:21', '0', 1),
(10029, 210001, 1000000, 100000, 6, 36, 9.9, 19.8, 10, 8, 6, 11.5, 14, '2016-09-23 07:41:48', '0', 1),
(10028, 210001, 500000, 100000, 6, 36, 9.9, 19.8, 10, 8, 6, 11.5, 14, '2016-09-23 07:41:10', '0', 1),
(10027, 210001, 300000, 100000, 6, 36, 9, 18, 9, 7.2, 5.4, 11.5, 14, '2016-09-23 07:40:38', '0', 1),
(10026, 210001, 100000, 50000, 3, 24, 4, 16, 8, 6.4, 4.8, 11.5, 14, '2016-09-23 07:39:48', '0', 1),
(10025, 210001, 50000, 10000, 3, 24, 3.5, 14, 8, 6.4, 4.8, 11.5, 14, '2016-09-23 07:38:44', '0', 1),
(10023, 210001, 20000, 10000, 3, 24, 3, 12, 8, 6.4, 4.8, 11.5, 14, '2016-09-23 07:36:55', '0', 1),
(10036, 210002, 1000000, 100000, 1, 36, 0, 8, 10, 8, 6, 11.5, 14, '2016-09-23 07:45:53', '0', 1);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `SettingsID` int(21) NOT NULL,
  `SiteTitle` varchar(256) NOT NULL,
  `TagLine` varchar(256) NOT NULL,
  `SiteUrl` varchar(128) NOT NULL,
  `NewUserRole` int(21) NOT NULL,
  `TimeZone` varchar(128) NOT NULL,
  `SiteLanguage` varchar(128) NOT NULL,
  `Redirects` text NOT NULL,
  `Favicon` int(21) NOT NULL,
  `Logo` int(21) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`SettingsID`, `SiteTitle`, `TagLine`, `SiteUrl`, `NewUserRole`, `TimeZone`, `SiteLanguage`, `Redirects`, `Favicon`, `Logo`) VALUES
(1, 'Odeon & Co.', 'Odeon & Co.', 'http://odeonco.loc/', 5, 'Asia/Singapore', 'en', 'YTo5OntpOjE7czoxOToiaHR0cDovL29kZW9uY28ubG9jLyI7aToyO3M6MTg6Imh0dHA6Ly9vZGVvbmNvLmxvYyI7aTozO3M6MjY6Imh0dHA6Ly9vZGVvbmNvLmxvYy9jbGllbnRzIjtpOjQ7czoyNjoiaHR0cDovL29kZW9uY28ubG9jL2NsaWVudHMiO2k6NTtzOjI2OiJodHRwOi8vb2Rlb25jby5sb2MvY2xpZW50cyI7aTo2O3M6MTg6Imh0dHA6Ly9vZGVvbmNvLmxvYyI7aTo3O3M6MTg6Imh0dHA6Ly9vZGVvbmNvLmxvYyI7aTo4O3M6MTg6Imh0dHA6Ly9vZGVvbmNvLmxvYyI7aTo5O3M6MTg6Imh0dHA6Ly9vZGVvbmNvLmxvYyI7fQ==', 1229, 1230);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(21) NOT NULL,
  `Email` varchar(64) NOT NULL,
  `Password` varchar(128) NOT NULL,
  `Level` int(11) NOT NULL,
  `Capability` longtext NOT NULL,
  `SendEmail` int(1) NOT NULL DEFAULT '0',
  `HashKey` varchar(64) NOT NULL,
  `Active` int(1) NOT NULL DEFAULT '0',
  `DateAdded` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Email`, `Password`, `Level`, `Capability`, `SendEmail`, `HashKey`, `Active`, `DateAdded`) VALUES
(100000, 'moisesg@cutearts.org', 'SbGkKvx6LA5AgxaFQX0/sPYWpAdI4+sGnq5qAaVObUc=', 1, '1', 1, '44131823d5de90da3523fab70d081d7b', 1, '2016-07-18 11:16:31'),
(100001, 'chris@odeonco.com', 'u0PmVUI20/wfXjEv5nqHdVUwryUwKGCev/A4514m+pc=', 2, '1', 1, '', 1, '2016-06-01 02:04:08'),
(100033, 'fred@simpson.com', 'b3S8wzdb/g0rrdPcOmdk7fuMhENwHiYysh3YFz9JY2I=', 4, '0', 0, '0c5884668180982891480d6332b7fdd6', 1, '2016-07-12 01:27:38'),
(100035, 'golfiedretyuio@freemail.com', 'fpaAA0QdaiCaz+ZVYlx/ovql94KCYOSHpGtlAJd/YuU=', 3, '0', 0, '691b62d0f48055bd8dbed21bbc5118c6', 1, '2016-07-25 09:37:23'),
(100036, 'artemyo.molave@gmail.com', 'esl4ntzuV3BaMVDCTv/CHc8HD6pfdJFnh+yblN/6Rg4=', 3, '0', 0, 'a8c5c2f9324a84161c0b00a473f93477', 1, '2016-07-28 08:45:45'),
(100037, 'warthog.levy@odeonco.com', 'bi/05QjYON3PYFWh7j3t+Wjo2LJ2zv1U6/6VRJMC170=', 4, '0', 0, '72f83a0c121ece205c55d0072d5d3e52', 1, '2016-07-28 09:33:33'),
(100046, 'wasadfer@adfdfdfsdfs.com', 'qJVO+HKGC4MMmviUigYjW3jgw3o4Nrfuff6T8aHBj4s=', 1, '0', 0, '526b1381917cd7ff06ea412bc3cf4477', 1, '2016-09-05 11:18:00'),
(100049, 'besperat@gmail.com', 'v+sYlWhbSWxNiRVkbSg2/gYZ8YA2sHpTHnfdbJiTmPA=', 5, '0', 0, '0518986b6a61a65c0991ebfb9444a6d3', 1, '2016-09-05 12:26:25'),
(100050, 'wasadfasdfsadfsadfer@adfdfdfsdfs.com', 'MWWDHdY1Zfihk3IpJmYm5ASyrKejejF3tEgzcA3u07c=', 5, '0', 0, '91e16199de4d8f1144e4527635db4586', 1, '2016-09-05 22:47:27'),
(100051, 'ryandumajil@gmail.com', 'WjeuYxI9uv8m4NDTYZY5ThM3JZOtafd8j0SHj11++6o=', 1, '0', 0, '0c3dc8d475dbccda755b666f1c28eb85', 1, '2016-09-26 04:03:56'),
(100052, 'ryandumajil@gmail.com', 'eud7Z5rPJrAgwFxcf4QTxBzMR97oYEgBaOZm6NsAtts=', 5, '0', 0, 'c4c751e3929a318da2a1b7cc6e461522', 1, '2016-10-04 18:05:23'),
(100078, 'artemyo.molave@gmail.com', 'JdUr0wiSEUsAsVMprU5YiBBz2CVljm/p2ExVUk3zhfM=', 5, '0', 0, 'd3e71353fbdc0fb37e028e22e82ad53c', 1, '2016-10-11 01:00:58'),
(100079, 'a@com.com', '2mY02K8ZG4SMa+I2orFpdO5UYee1GJvpaaTuq5kYu5g=', 5, '0', 0, 'cca509f0193e0f12b03e665b317fe878', 1, '2016-10-11 05:45:44');

-- --------------------------------------------------------

--
-- Table structure for table `user_capabilities`
--

CREATE TABLE `user_capabilities` (
  `UserCapabilityID` int(11) NOT NULL,
  `UserCapabilityGroupID` int(11) NOT NULL,
  `Name` varchar(256) NOT NULL,
  `Description` text NOT NULL,
  `Active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_capabilities`
--

INSERT INTO `user_capabilities` (`UserCapabilityID`, `UserCapabilityGroupID`, `Name`, `Description`, `Active`) VALUES
(1, 0, 'Administer All', '', 1),
(2, 1, 'Delete Users', '', 1),
(3, 1, 'Edit Users', '', 1),
(4, 1, 'Add Users', '', 1),
(5, 2, 'Delete Clients', '', 1),
(6, 2, 'Edit Clients', '', 1),
(7, 2, 'Add Clients', '', 1),
(8, 3, 'Delete Casefiles', '', 1),
(9, 3, 'Edit Casefiles', '', 1),
(10, 3, 'Add Casefiles', '', 1),
(11, 4, 'Delete Agents', '', 1),
(12, 4, 'Edit Agents', '', 1),
(13, 4, 'Add Agents', '', 1),
(14, 5, 'Delete Agency', '', 1),
(15, 5, 'Edit Agency', '', 1),
(16, 5, 'Add Agency', '', 1),
(17, 6, 'View Network Hierarchy', '', 1),
(18, 6, 'Commission Report', '', 1),
(19, 3, 'Manage Uploaded Documents', '', 1),
(20, 3, 'Manage Application', '', 1),
(21, 3, 'Download Documents', '', 1),
(23, 3, 'Send Email', '', 1),
(24, 7, 'View API', '', 1),
(25, 1, 'View Users', '', 1),
(26, 2, 'View Clients', '', 1),
(27, 3, 'View Casefiles', '', 1),
(28, 4, 'View Agents', '', 1),
(29, 5, 'View Agency', '', 1),
(30, 6, 'View Sales Report', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_capability_groups`
--

CREATE TABLE `user_capability_groups` (
  `UserCapabilityGroupID` int(11) NOT NULL,
  `Name` varchar(256) NOT NULL,
  `Active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_capability_groups`
--

INSERT INTO `user_capability_groups` (`UserCapabilityGroupID`, `Name`, `Active`) VALUES
(0, 'Admin', 1),
(1, 'Users', 1),
(2, 'Clients', 1),
(3, 'Casefiles', 1),
(4, 'Agents', 1),
(5, 'Agency', 1),
(6, 'Reports', 1),
(7, 'API', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_levels`
--

CREATE TABLE `user_levels` (
  `UserLevelID` int(11) NOT NULL,
  `Name` varchar(64) NOT NULL,
  `Description` text NOT NULL,
  `Link` text NOT NULL,
  `Capability` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_levels`
--

INSERT INTO `user_levels` (`UserLevelID`, `Name`, `Description`, `Link`, `Capability`) VALUES
(1, 'Administrator', 'Super Admin & Backend Manager', '/', 'YToyOTp7aToxO3M6MTQ6IkFkbWluaXN0ZXIgQWxsIjtpOjI7czoxMjoiRGVsZXRlIFVzZXJzIjtpOjM7czoxMDoiRWRpdCBVc2VycyI7aTo0O3M6OToiQWRkIFVzZXJzIjtpOjI1O3M6MTA6IlZpZXcgVXNlcnMiO2k6NTtzOjE0OiJEZWxldGUgQ2xpZW50cyI7aTo2O3M6MTI6IkVkaXQgQ2xpZW50cyI7aTo3O3M6MTE6IkFkZCBDbGllbnRzIjtpOjI2O3M6MTI6IlZpZXcgQ2xpZW50cyI7aTo4O3M6MTY6IkRlbGV0ZSBDYXNlZmlsZXMiO2k6OTtzOjE0OiJFZGl0IENhc2VmaWxlcyI7aToxMDtzOjEzOiJBZGQgQ2FzZWZpbGVzIjtpOjE5O3M6MjU6Ik1hbmFnZSBVcGxvYWRlZCBEb2N1bWVudHMiO2k6MjA7czoxODoiTWFuYWdlIEFwcGxpY2F0aW9uIjtpOjIxO3M6MTg6IkRvd25sb2FkIERvY3VtZW50cyI7aToyMztzOjEwOiJTZW5kIEVtYWlsIjtpOjI3O3M6MTQ6IlZpZXcgQ2FzZWZpbGVzIjtpOjExO3M6MTM6IkRlbGV0ZSBBZ2VudHMiO2k6MTI7czoxMToiRWRpdCBBZ2VudHMiO2k6MTM7czoxMDoiQWRkIEFnZW50cyI7aToyODtzOjExOiJWaWV3IEFnZW50cyI7aToxNDtzOjEzOiJEZWxldGUgQWdlbmN5IjtpOjE1O3M6MTE6IkVkaXQgQWdlbmN5IjtpOjE2O3M6MTA6IkFkZCBBZ2VuY3kiO2k6Mjk7czoxMToiVmlldyBBZ2VuY3kiO2k6MTc7czoyMjoiVmlldyBOZXR3b3JrIEhpZXJhcmNoeSI7aToxODtzOjE3OiJDb21taXNzaW9uIFJlcG9ydCI7aTozMDtzOjE3OiJWaWV3IFNhbGVzIFJlcG9ydCI7aToyNDtzOjg6IlZpZXcgQVBJIjt9'),
(2, 'Manager', 'State administrator, manage city representative and agents', '/', 'YToxOTp7aTo2O3M6MTI6IkVkaXQgQ2xpZW50cyI7aTo3O3M6MTE6IkFkZCBDbGllbnRzIjtpOjI2O3M6MTI6IlZpZXcgQ2xpZW50cyI7aTo5O3M6MTQ6IkVkaXQgQ2FzZWZpbGVzIjtpOjEwO3M6MTM6IkFkZCBDYXNlZmlsZXMiO2k6MTk7czoyNToiTWFuYWdlIFVwbG9hZGVkIERvY3VtZW50cyI7aToyMDtzOjE4OiJNYW5hZ2UgQXBwbGljYXRpb24iO2k6MjE7czoxODoiRG93bmxvYWQgRG9jdW1lbnRzIjtpOjIzO3M6MTA6IlNlbmQgRW1haWwiO2k6Mjc7czoxNDoiVmlldyBDYXNlZmlsZXMiO2k6MTI7czoxMToiRWRpdCBBZ2VudHMiO2k6MTM7czoxMDoiQWRkIEFnZW50cyI7aToyODtzOjExOiJWaWV3IEFnZW50cyI7aToxNTtzOjExOiJFZGl0IEFnZW5jeSI7aToxNjtzOjEwOiJBZGQgQWdlbmN5IjtpOjI5O3M6MTE6IlZpZXcgQWdlbmN5IjtpOjE3O3M6MjI6IlZpZXcgTmV0d29yayBIaWVyYXJjaHkiO2k6MTg7czoxNzoiQ29tbWlzc2lvbiBSZXBvcnQiO2k6MzA7czoxNzoiVmlldyBTYWxlcyBSZXBvcnQiO30='),
(3, 'Agency', 'City representative manage agents', '/clients', 'YTo2OntpOjY7czoxMjoiRWRpdCBDbGllbnRzIjtpOjc7czoxMToiQWRkIENsaWVudHMiO2k6MjY7czoxMjoiVmlldyBDbGllbnRzIjtpOjk7czoxNDoiRWRpdCBDYXNlZmlsZXMiO2k6MTA7czoxMzoiQWRkIENhc2VmaWxlcyI7aToyNztzOjE0OiJWaWV3IENhc2VmaWxlcyI7fQ=='),
(4, 'Agent', 'Agents', '/clients', 'YTo2OntpOjY7czoxMjoiRWRpdCBDbGllbnRzIjtpOjc7czoxMToiQWRkIENsaWVudHMiO2k6MjY7czoxMjoiVmlldyBDbGllbnRzIjtpOjk7czoxNDoiRWRpdCBDYXNlZmlsZXMiO2k6MTA7czoxMzoiQWRkIENhc2VmaWxlcyI7aToyNztzOjE0OiJWaWV3IENhc2VmaWxlcyI7fQ=='),
(5, 'Client', 'Clients ', '/profile', 'YToxOntpOjI3O3M6MTQ6IlZpZXcgQ2FzZWZpbGVzIjt9'),
(6, 'Local Reps', 'Country Reps', '/clients', 'YTo2OntpOjY7czoxMjoiRWRpdCBDbGllbnRzIjtpOjc7czoxMToiQWRkIENsaWVudHMiO2k6MjY7czoxMjoiVmlldyBDbGllbnRzIjtpOjk7czoxNDoiRWRpdCBDYXNlZmlsZXMiO2k6MTA7czoxMzoiQWRkIENhc2VmaWxlcyI7aToyNztzOjE0OiJWaWV3IENhc2VmaWxlcyI7fQ=='),
(7, 'State Reps', 'State Reps', '/clients', 'YTo2OntpOjY7czoxMjoiRWRpdCBDbGllbnRzIjtpOjc7czoxMToiQWRkIENsaWVudHMiO2k6MjY7czoxMjoiVmlldyBDbGllbnRzIjtpOjk7czoxNDoiRWRpdCBDYXNlZmlsZXMiO2k6MTA7czoxMzoiQWRkIENhc2VmaWxlcyI7aToyNztzOjE0OiJWaWV3IENhc2VmaWxlcyI7fQ=='),
(8, 'City Reps', 'City Reps', '/clients', 'YTo2OntpOjY7czoxMjoiRWRpdCBDbGllbnRzIjtpOjc7czoxMToiQWRkIENsaWVudHMiO2k6MjY7czoxMjoiVmlldyBDbGllbnRzIjtpOjk7czoxNDoiRWRpdCBDYXNlZmlsZXMiO2k6MTA7czoxMzoiQWRkIENhc2VmaWxlcyI7aToyNztzOjE0OiJWaWV3IENhc2VmaWxlcyI7fQ=='),
(9, 'Developer', 'Developer, API access', '/profile', 'YToxOntpOjI0O3M6ODoiVmlldyBBUEkiO30=');

-- --------------------------------------------------------

--
-- Table structure for table `user_meta`
--

CREATE TABLE `user_meta` (
  `UserMetaID` int(21) NOT NULL,
  `UserID` int(21) NOT NULL,
  `Language` varchar(128) NOT NULL,
  `Avatar` int(21) NOT NULL,
  `Salutation` varchar(32) NOT NULL,
  `FirstName` varchar(64) NOT NULL,
  `LastName` varchar(64) NOT NULL,
  `NickName` varchar(128) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `CivilStatus` varchar(64) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `Mobile` varchar(32) NOT NULL,
  `JobTitle` varchar(64) NOT NULL,
  `Occupation` varchar(64) NOT NULL,
  `Address` varchar(256) NOT NULL,
  `Address2` varchar(256) NOT NULL,
  `Address3` varchar(256) NOT NULL,
  `Address4` varchar(256) NOT NULL,
  `City` varchar(64) NOT NULL,
  `State` varchar(64) NOT NULL,
  `Country` varchar(64) NOT NULL,
  `PostalCode` varchar(16) NOT NULL,
  `Bio` text NOT NULL,
  `IdNumber` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_meta`
--

INSERT INTO `user_meta` (`UserMetaID`, `UserID`, `Language`, `Avatar`, `Salutation`, `FirstName`, `LastName`, `NickName`, `DateOfBirth`, `Gender`, `CivilStatus`, `Phone`, `Mobile`, `JobTitle`, `Occupation`, `Address`, `Address2`, `Address3`, `Address4`, `City`, `State`, `Country`, `PostalCode`, `Bio`, `IdNumber`) VALUES
(1, 100000, '', 1234, '', 'Moises', 'Goloyugo', 'Mom', '1986-12-25', 'M', '', '09278585028', '', '', '', 'Bulihan', '', '', '', 'Silang', 'Cavite', 'Philippines', '4118', 'Whatever', ''),
(2, 100001, '', 0, '', 'Chris', 'Chua', 'C', '0000-00-00', 'M', '', '0936258469', '', '', '', 'Zhenzhen', '', '', '', 'Shangrila', 'Zhaozhao', 'Singapore', '', 'Handsome boy we', ''),
(3, 100021, 'en', 0, '', 'Mark', 'Anthony', '', '0000-00-00', 'M', '', '5129002', '', '', '', 'Bulihan', '', '', '', 'Silang', 'Cavite', 'Philippines', '4118', 'Im Good hehe', '134685258-RSM'),
(5, 100033, 'en', 0, '', 'Fred', 'Simpson', '', '0000-00-00', 'M', '', '5129002', '', '', '', 'Winan', '', '', '', 'Ever', 'Fragiz', 'China', '3214695', 'Samoa', '134685258-XYZ1'),
(6, 100034, '', 0, '', 'ewrtyuio', 'retyuio', 'ertyuio', '0000-00-00', 'M', '', '134567890', '', '', '', 'gsdgsdf', '', '', '', 'dfgdsfg', 'dsfgdfsg', 'Netherlands Antilles', '1234', 'qtqerttetet', ''),
(7, 100035, 'en', 0, '', 'Golfied', 'Retyuio', '', '0000-00-00', 'M', '', '31258963', '', '', '', 'Casiles', '', '', '', 'Nuvalis', 'Tagaytays', 'China', '43255', 'Let&#39;s fix this text sss ', '312652'),
(8, 100036, 'en', 0, '', 'Artemyo', 'Molave', '', '0000-00-00', 'M', '', '3698525896', '', '', '', 'Shua', '', '', '', 'Temo', 'Lacsa', 'Netherlands Antilles', '6495', 'yesyt', '13658236'),
(9, 100037, 'en', 849, '', 'Levy', 'Powel', '', '0000-00-00', 'M', '', '369715236', '', '', '', 'Lumpia', '', '', '', 'Sariwa', 'Shanghai', 'China', '36452', '', '312546895'),
(11, 100039, 'en', 0, '', 'Mark', 'Goloyugo', '', '0000-00-00', 'M', '', '5129112', '', '', '', 'Phase', '', '', '', 'One', 'Aey', 'Philippines', '4112', '', '999999'),
(12, 100040, 'en', 0, 'Ms', 'Momo', 'Kamo', '', '1969-12-31', 'F', 'MARRIED', '123456789', '123456987', 'COO', 'Businesswoman', 'Wanderlei', 'Primary address', 'Secondary address', 'Secondary address', '', '', 'Philippines', '', '', '97456852'),
(15, 100043, 'en', 0, 'Dato', 'Atarma', 'Mutarwi', '', '1990-02-14', 'M', '', '', '09996636956', 'Dato', 'Royal Governor', 'Saba Malaysia', 'Saba', '', '', '', '', 'Malaysia', '', '', '3124569858585'),
(16, 100044, 'en', 0, 'Mr', 'asdfsadf', 'sadfsdaf', '', '1990-01-11', 'M', '', '', 'sdf', 'fsadf', 'asdfsad', 'sadfasfdfasdf', 'sadf', '8765asdfsadf', 'sadf', '', '', 'China', '', '', 'sdaf'),
(17, 100045, 'en', 0, 'Mr', 'asdf', 'sdaf', '', '1992-04-05', 'M', '', '', 'asdf', 'sdf', 'asdfsadsdf', 'asdf', '', 'sdaf', 'sadf', '', '', 'China', '', '', 'aS'),
(18, 100046, '', 167, '', 'asdfsadfsadf', 'asdfsdfa', 'sdafsadf', '0000-00-00', 'M', '', '3698525896', '', '', '', 'sadfsadfsadf', '', '', '', 'asdfasdf', 'sfd', 'Philippines', '1234', 'asdfsdaf', ''),
(19, 100047, 'en', 0, 'Mr', 'iuytre', 'trewq', '', '1988-02-08', 'M', '', '', '12341241', 'tre', 'trwq', 'tyurturty', 'rety erty ', 'm erwty erty ', 'erty rety ', '', '', 'China', '', '', 'ytrewq'),
(21, 100049, 'en', 0, 'Mr', 'Besperat', 'Shuna', '', '1989-04-02', 'M', '', '', '09996636956', 'Power Forward', 'Basketball Player', 'sadf', 'Timoto matayone', 'Washum miming', 'Tomam', '', '', 'China', '', '', 'R3265FEG12'),
(22, 100050, 'en', 0, 'Mr', 'sadf', 'sdf', '', '1973-02-04', 'M', '', '', 'sadf', 'sadf', 'sadf', 'sadfasfdfasdfasdf', 'sdf', '8765asdfsadfs', 'sdaf', '', '', 'China', '', '', 'sadf'),
(23, 100051, '', 848, '', 'Ryan', 'Dumajil', 'Ryan', '0000-00-00', 'M', '', '4604249', '', '', '', 'Brgy Memije', '', '', '', 'GMA', 'Cavite', 'Philippines', '4117', 'Whatever', ''),
(24, 100052, 'en', 0, 'Mr', 'sdadasdasd', 'dsadasd', '', '1998-09-04', 'M', '', '', '321321', 'dsadas', 'dsa', 'dasda', '', '', '', '', '', 'China', '', '', 'asdasdasda'),
(25, 100053, 'en', 0, 'Mr', 'Ryan', 'Dolontap', '', '1991-04-03', 'M', '', '', '23232', 'dsadasd', 'asdsadas', 'dsad', 'asdas', '', '', '', '', 'China', '', '', 'asdasdasdas'),
(26, 100054, 'en', 0, 'Mr', 'Ryan', 'Dolontap', '', '1991-04-03', 'M', '', '', '23232', 'dsadasd', 'asdsadas', 'dsad', 'asdas', '', '', '', '', 'China', '', '', 'asdasdasdas'),
(50, 100078, 'en', 0, 'Mr', 'Artemyo', 'Molave', '', '1980-01-07', 'M', '', '', '09996636956', 'Marketing Supervisor', 'Businessman', 'Casile', 'Mumbai', 'Washum miming', 'Tomam', '', '', 'China', '', '', '134685258-RSM'),
(51, 100079, 'en', 0, 'Mr', 'sdsd', 'asdfsadf', '', '2000-01-03', 'M', '', '', 'asdf', 'sdafasdf', 'asdfsadf', 'asdfsadf', 'sadf', 'sasdaf', 'sadfsdaf', '', '', 'China', '', '', 'dfghjhk');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`AccountID`),
  ADD KEY `CaseFileID` (`AccountID`),
  ADD KEY `CaseFileID_2` (`AccountID`);

--
-- Indexes for table `account_meta`
--
ALTER TABLE `account_meta`
  ADD PRIMARY KEY (`AccountMetaID`),
  ADD KEY `CaseFileID` (`AccountMetaID`),
  ADD KEY `CaseFileID_2` (`AccountMetaID`);

--
-- Indexes for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`BankAccountID`),
  ADD KEY `BankAccountID` (`BankAccountID`),
  ADD KEY `BankAccountID_2` (`BankAccountID`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`FileID`),
  ADD KEY `DocumentID` (`FileID`),
  ADD KEY `FileID` (`FileID`);

--
-- Indexes for table `file_items`
--
ALTER TABLE `file_items`
  ADD PRIMARY KEY (`FileItemID`),
  ADD KEY `DocumentID` (`FileID`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`OptionID`);

--
-- Indexes for table `option_groups`
--
ALTER TABLE `option_groups`
  ADD PRIMARY KEY (`OptionGroupID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductID`);

--
-- Indexes for table `product_items`
--
ALTER TABLE `product_items`
  ADD PRIMARY KEY (`ProductItemID`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`SettingsID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `user_capabilities`
--
ALTER TABLE `user_capabilities`
  ADD PRIMARY KEY (`UserCapabilityID`),
  ADD KEY `UserCapabilityID` (`UserCapabilityID`);

--
-- Indexes for table `user_capability_groups`
--
ALTER TABLE `user_capability_groups`
  ADD PRIMARY KEY (`UserCapabilityGroupID`);

--
-- Indexes for table `user_levels`
--
ALTER TABLE `user_levels`
  ADD PRIMARY KEY (`UserLevelID`);

--
-- Indexes for table `user_meta`
--
ALTER TABLE `user_meta`
  ADD PRIMARY KEY (`UserMetaID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `AccountID` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10049;
--
-- AUTO_INCREMENT for table `account_meta`
--
ALTER TABLE `account_meta`
  MODIFY `AccountMetaID` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10028;
--
-- AUTO_INCREMENT for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `BankAccountID` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `FileID` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1279;
--
-- AUTO_INCREMENT for table `file_items`
--
ALTER TABLE `file_items`
  MODIFY `FileItemID` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;
--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `OptionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `option_groups`
--
ALTER TABLE `option_groups`
  MODIFY `OptionGroupID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ProductID` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=210006;
--
-- AUTO_INCREMENT for table `product_items`
--
ALTER TABLE `product_items`
  MODIFY `ProductItemID` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10037;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `SettingsID` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100080;
--
-- AUTO_INCREMENT for table `user_capabilities`
--
ALTER TABLE `user_capabilities`
  MODIFY `UserCapabilityID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `user_capability_groups`
--
ALTER TABLE `user_capability_groups`
  MODIFY `UserCapabilityGroupID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `user_levels`
--
ALTER TABLE `user_levels`
  MODIFY `UserLevelID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `user_meta`
--
ALTER TABLE `user_meta`
  MODIFY `UserMetaID` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
