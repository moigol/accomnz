<?php
/**
 * PHP 4, 5
 *
 * MyPHPFrame(tm) : Rapid Development Framework (http://cutearts.org)
 * Copyright (c) MyPHPFrame Solutions (http://cutearts.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @location      conf/routes.php
 * @package       configuration
 * @version       MyPHPFrame(tm) v 1.03
 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
 */

// TO DO: implement this as a substitute to custom routing
// Routes::get('main','index');
// Routes::post('users','login');